hpb Generator
==================

This directory contains the generator for the [`hpb`
API](https://github.com/protocolbuffers/protobuf/tree/main/hpb), an
experimental C++ protobuf implementation. Most users should use the standard
C++ implementation
[here](https://github.com/protocolbuffers/protobuf/tree/main/src).
