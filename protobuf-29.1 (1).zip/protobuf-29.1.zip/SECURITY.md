To report security concerns or vulnerabilities within protobuf, please use
Google's official channel for reporting these.

https://www.google.com/appserve/security-bugs/m2/new
